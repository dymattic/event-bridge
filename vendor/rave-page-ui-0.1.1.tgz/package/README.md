# @rave-page/ui

rave.page design-system UI primitives. React 19 + Tailwind v4 + Radix, `cva` +
`cn` (clsx + tailwind-merge). **This package is the source of truth**;
`app/src/components/ui/*` in the rave.page web app are thin shims that re-export
from here (injecting app i18n, the ui-preferences store, the consent-gated
`Image`, and WebGL FX).

## Install (workspace)

Workspace consumers use `"@rave-page/ui": "workspace:*"`. Before an npm publish,
an external repo can point at a local checkout with
`"@rave-page/ui": "link:../rave.page/packages/ui"` (or `file:`), then switch to
the published version once it's on the registry.

## Setup (Tailwind v4 consumer)

1. Import the tokens and tell Tailwind to scan the kit source for classes:

   ```css
   @import "tailwindcss";
   @import "@rave-page/ui/tokens.css";
   @source "../node_modules/@rave-page/ui/src";
   ```

   `@source` is required - Tailwind only generates the utility classes it can
   see, and the kit's class strings live in its `src/`. Adjust the relative
   path to point at wherever `@rave-page/ui` resolves from your CSS file.

2. Fonts (Orbitron). If your app doesn't already load Orbitron, add:

   ```css
   @import "@rave-page/ui/font.css";
   ```

   and copy `node_modules/@rave-page/ui/fonts/` next to your bundled CSS (the
   `@font-face` `url()` is relative to the CSS file), or rewrite the url to
   your bundler's asset path. The rave.page app already serves Orbitron, so it
   imports `tokens.css` only (no `font.css`) to avoid double-loading.

3. Mount the providers once near your app root:

   ```tsx
   import {TooltipProvider, NotificationProvider} from "@rave-page/ui";

   <TooltipProvider>
     <NotificationProvider>
       {/* app; render <Toast/> somewhere inside */}
     </NotificationProvider>
   </TooltipProvider>
   ```

   `TooltipProvider` is required by any `Button`/`IconButtonWithTooltip` that
   uses `tooltip`. `NotificationProvider` + `<Toast/>` back `useNotification()`.

### External esbuild + Tailwind CLI consumer (e.g. event-bridge)

Same three steps. With the Tailwind CLI, run e.g.
`tailwindcss -i src/app.css -o dist/app.css` where `src/app.css` contains the
`@import`/`@source` lines above (path relative to `src/app.css`, e.g.
`@source "../node_modules/@rave-page/ui/src";`). Copy the font file into your
output dir. React 19 and a lucide-react in `>=0.560 <2` are peer deps you
provide (event-bridge's 1.34 is fine). esbuild bundles the kit's ESM from
`@rave-page/ui` (its `.` export resolves to `dist/` once published, or `src/`
in a workspace/`link:` setup).

## Peers

`react` ^19, `react-dom` ^19, `lucide-react` `>=0.560.0 <2` (you pick the copy;
the kit imports only icons present in both 0.562 and 1.34).

## The `labels` pattern (i18n-agnostic)

Components carry no i18n. User-visible strings are optional `labels` props with
English defaults exported per component as `<component>DefaultLabels` (e.g.
`dialogDefaultLabels`, `smartSelectDefaultLabels`, `confirmDialogDefaultLabels`,
`datePickerDefaultLabels`, `dateTimePickerDefaultLabels`, `toastDefaultLabels`,
`sheetDefaultLabels`, `colorPickerDefaultLabels`, `inputDialogDefaultLabels`,
`renameDialogDefaultLabels`). Pass a partial `labels` object to localize; the
rave.page app shim passes `t('…')` strings.

## Inventory

| Group | Exports |
|---|---|
| Utilities | `cn`, `useFloatingPosition` |
| Badge | `Badge`, `badgeVariants` |
| Button + Tooltip | `Button`, `buttonVariants`, `IconButtonWithTooltip`, `Tooltip`, `TooltipTrigger`, `TooltipContent`, `TooltipProvider` |
| Card | `Card`, `CardHeader`, `CardFooter`, `CardTitle`, `CardDescription`, `CardContent` (`renderFx` prop for WebGL overlays) |
| Dashboard | `DashboardCard`, `DashboardTile`, `DashboardListRow`, `dashboardCardVariants`, `StatCard` |
| Feedback | `EmptyState`, `LoadingSpinner`, `Toast`, `NotificationProvider`, `useNotification` |
| Form controls | `Input`, `Textarea`, `Label`, `Checkbox`, `Switch`, `RangeSlider`, `SmartSelect` (`renderOptionImage` prop), `ColorPicker`, `PRESET_COLORS` |
| Date/time | `DatePicker`, `DateTimePicker` |
| Overlays | `Dialog` family, `ConfirmDialog`, `InputDialog`, `RenameDialog`, `Sheet` family, `Popover` family, `DropdownMenu` family |
| Layout | `Tabs` family, `Separator`, `DataTable` |

Left in the app (not extracted): `Image`, `Markdown`, `LinkedMedia`,
`MediaSkeleton`, `Resizable`/`ResizableBox`, `EventCalendarPicker`,
`MiniCalendarPicker`, `UiPreferencesPanel`, `FlowCard` (router dep). See
`PROVENANCE.md`.

## License

MIT (`LICENSE`). rave.page has no root LICENSE yet - confirm licensing before
any public npm publish.
