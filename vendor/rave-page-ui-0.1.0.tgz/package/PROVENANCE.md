# PROVENANCE - @rave-page/ui

Every file was extracted from the rave.page web app at development commit
**`66fb5dc2`** (`origin/development`, "Fix GenreSelect placeholder i18n on
TimelineHero"). Source paths are relative to the repo root. This package is now
the source of truth; the listed app paths became thin shims (see Unit 2).

## Transformations applied (decoupling from the host app)

The kit must not import `@mui/*`, `@emotion/*`, `react-i18next`, `i18next`,
`zustand`, `@tanstack/*`, `react-router*`, the `@/` alias, or any relative path
escaping `src/` (enforced by `scripts/check-imports.mjs`). To get there:

- **i18n → `labels` props.** Every `useTranslation('common')` call was removed.
  User-visible strings became `labels` props with English defaults exported per
  component as `<component>DefaultLabels`. The app shim passes translated
  strings (`t('…')`); external consumers get English or supply their own.
- **MUI `Tooltip` → Radix Tooltip.** `Button` now renders
  `@radix-ui/react-tooltip`; the kit exports `TooltipProvider` (mount once at
  the app root).
- **MUI `CircularProgress` → CSS spinner.** `LoadingSpinner` is a brand-token
  CSS ring (`animate-spin`, `motion-reduce:animate-none`), no MUI.
- **zustand store → props.** `Dialog`'s persisted-size behaviour (was
  `useUiPreferencesStore`) is now `initialSize` + `onSizeChange` props with a
  session-only default (no persistence unless `onSizeChange` is supplied). The
  `resizableId` prop moved to the app shim, which maps it to the store.
- **`@/components/ui/Image` → `renderOptionImage` prop.** `SmartSelect` renders
  a plain `<img>` by default; the app shim injects its consent-gated `Image`.
- **`@/webgl/fx/*` → `renderFx` prop.** `Card`'s `fx="ripple"|"wire"` overlay
  is injected by the consumer; the kit ships no WebGL. The app shim defaults
  `renderFx` to `RippleOverlay` / `BorderWire`.
- **Import rewrites.** `@/lib/utils` → `../lib/cn`; `@/hooks/useFloatingPosition`
  → `../hooks/useFloatingPosition`; `@/components/ui/X` / `./X` → `./X` (kit
  base dir); `@/components/shared/SmartSelect` → `./SmartSelect`.

## File-by-file

| Kit file | Source path (@ `66fb5dc2`) | Transformations |
|---|---|---|
| `src/lib/cn.ts` | `app/src/lib/utils.ts` (`cn`) | none (verbatim) |
| `src/hooks/useFloatingPosition.ts` | `app/src/hooks/useFloatingPosition.ts` | verbatim |
| `src/styles/tokens.css` | `app/src/index.css` (`@theme` + DS `:root`), `app/src/critical.css` (density tokens) | moved verbatim; added `--breakpoint-xxl`; `@font-face` split into `font.css` |
| `src/styles/font.css` | `app/src/index.css` / app font loading | new: Orbitron `@font-face` only |
| `src/base/Badge.tsx` | `app/src/components/ui/Badge.tsx` | cn import |
| `src/base/Button.tsx` | `app/src/components/ui/Button.tsx` | cn import; MUI Tooltip → Radix (`./Tooltip`) |
| `src/base/Tooltip.tsx` | new (replaces MUI Tooltip) | Radix tooltip + `TooltipProvider` |
| `src/base/IconButtonWithTooltip.tsx` | `app/src/components/ui/IconButtonWithTooltip.tsx` | delegates to `./Button` |
| `src/base/Card.tsx` | `app/src/components/ui/Card.tsx` | cn import; `@/webgl/fx/*` → `renderFx` prop |
| `src/base/DashboardCard.tsx` | `app/src/components/ui/DashboardCard.tsx` | cn import |
| `src/base/StatCard.tsx` | `app/src/components/ui/StatCard.tsx` | cn import |
| `src/base/EmptyState.tsx` | `app/src/components/ui/EmptyState.tsx` | cn import |
| `src/base/Input.tsx` | `app/src/components/ui/Input.tsx` | cn import |
| `src/base/Textarea.tsx` | `app/src/components/ui/Textarea.tsx` | cn import |
| `src/base/Label.tsx` | `app/src/components/ui/Label.tsx` | cn import |
| `src/base/Checkbox.tsx` | `app/src/components/ui/Checkbox.tsx` | cn import |
| `src/base/Switch.tsx` | `app/src/components/ui/Switch.tsx` | cn import |
| `src/base/RangeSlider.tsx` | `app/src/components/ui/RangeSlider.tsx` | cn import |
| `src/base/SmartSelect.tsx` | `app/src/components/shared/SmartSelect.tsx` | i18n → labels; `Image` → `renderOptionImage`; hook import path |
| `src/base/DatePicker.tsx` | `app/src/components/ui/DatePicker.tsx` | cn import; i18n → labels |
| `src/base/DateTimePicker.tsx` | `app/src/components/ui/DateTimePicker.tsx` | cn import; i18n → labels |
| `src/base/Dialog.tsx` | `app/src/components/ui/Dialog.tsx` | cn import; store → `initialSize`/`onSizeChange`; i18n → labels |
| `src/base/ConfirmDialog.tsx` | `app/src/components/ui/ConfirmDialog.tsx` | i18n → labels; imports `./Button`, `./Dialog` |
| `src/base/InputDialog.tsx` | `app/src/components/ui/InputDialog.tsx` | i18n → labels; imports `./*`, `./SmartSelect` (+ `selectLabels`) |
| `src/base/RenameDialog.tsx` | `app/src/components/ui/RenameDialog.tsx` | i18n → labels; wraps `./InputDialog` |
| `src/base/Sheet.tsx` | `app/src/components/ui/Sheet.tsx` | cn import; i18n → labels |
| `src/base/Popover.tsx` | `app/src/components/ui/Popover.tsx` | cn import |
| `src/base/DropdownMenu.tsx` | `app/src/components/ui/DropdownMenu.tsx` | cn import |
| `src/base/Tabs.tsx` | `app/src/components/ui/Tabs.tsx` | cn import |
| `src/base/Separator.tsx` | `app/src/components/ui/Separator.tsx` | cn import |
| `src/base/Toast.tsx` | `app/src/components/ui/Toast.tsx` | i18n → labels; reads `./NotificationContext` |
| `src/base/NotificationContext.tsx` | `app/src/components/ui/NotificationContext.tsx` | verbatim (+ exported `NotificationType`) |
| `src/base/LoadingSpinner.tsx` | `app/src/components/ui/LoadingSpinner.tsx` | MUI `CircularProgress` → CSS spinner |
| `src/base/DataTable.tsx` | `app/src/components/ui/DataTable.tsx` | cn import |
| `src/base/ColorPicker.tsx` | `app/src/components/ui/ColorPicker.tsx` | cn import; i18n → labels |
| `fonts/Orbitron-VariableFont_wght.ttf` | `rave-page-design-system/fonts/…` | copied |
| `fonts/Orbitron-OFL.txt` | `rave-page-design-system/fonts/…` | copied |

## Left in the app (NOT extracted)

- `Image`, `Markdown`, `LinkedMedia`, `MediaSkeleton`, `Resizable`,
  `ResizableBox`, `EventCalendarPicker`, `MiniCalendarPicker`,
  `UiPreferencesPanel` - all import consent context / api-client / router /
  stores / third-party libs (`react-markdown`, `react-resizable-panels`).
- `FlowCard` - hard-depends on `react-router-dom` `Link` (a forbidden import).
  Per the brief's "only if it has no app-only deps", it stays in the app.
